<?php

header('Location: campaign-list.php');
exit;