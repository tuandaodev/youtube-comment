

<footer class="page-footer font-small teal pt-4">
    <div class="footer-copyright py-3" style='text-align: right'>© 2020 Developer by
        <a href='skype:live:tuandao.dev?chat'> Tuan Dao</a>
    </div>
</footer>
</div>
</body>
</html>